API_URL = 'https://api.lazerpay.engineering/api/v1'

API_URL_INIT_TRANSACTION = f'{API_URL}/transaction/initialize'
API_URL_CONFIRM_TRANSACTION = f'{API_URL}/transaction/verify'
API_URL_GET_ACCEPTED_COINS = f'{API_URL}/coins'
API_URL_TRANSFER_FUNDS = f'{API_URL}/transfer'